# Aristotle's 12 virtues

An interactive flashcard tool for ranking Aristotle's 12 moral virtues by what matters to you, with space to write your own reflections.

## How to host on GitHub Pages

1. Create a new repository on GitHub (e.g. `virtues` or `aristotle-values`).
2. Upload `index.html` to the root of the repository.
3. Go to **Settings → Pages**.
4. Under **Source**, select branch `main` (or `master`) and folder `/ (root)`.
5. Save. After ~30 seconds your site will be live at `https://<your-username>.github.io/<repo-name>/`.

That's it. Share the link.

## How it works

- Drag the numbered handle to reorder.
- Use the ▲▼ arrows for fine adjustments.
- Tap "Reflect →" on any card to flip and write your thoughts.
- "Export reflections" copies your full ranking + notes as text.
- All data is saved in the browser's localStorage — nothing leaves the page.

## Customizing

The whole thing is one HTML file. Open it in any text editor to:
- Change the title or framing in the `<header>` section.
- Tweak the dark theme by editing the CSS variables at the top of `<style>`.
- Add or remove virtues by editing the `VIRTUES` array near the top of the script.
